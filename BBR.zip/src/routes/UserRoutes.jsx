import { Routes, Route } from "react-router-dom";

import UserLayout from "../components/layout/user/UserLayout";
import UserLogin from "../pages/auth/user/UserLogin";
import Register from "../pages/auth/user/Register";
import ForgotPassword from "../pages/auth/user/ForgotPassword";
import VerifyPasswordOtp from "../pages/auth/user/VerifyPasswordOtp";
import CreatePassword from "../pages/auth/user/CreatePassword";
import OrganizationLogin from "../pages/auth/user/OrganizationLogin";
import Dashboard from "../pages/user/Dashboard";
import Course from "../pages/user/Course";
import Notification from "../pages/user/Notification";
import Profile from "../pages/user/Profile";
import NewServiceRequest from "../pages/auth/user/NewServiceRequest";
import MyService from "../pages/user/MyService";
import MyService2 from "../pages/user/MyService2";


const UserRoutes = () => {
  return (
    <Routes>
        <Route path="/" element={<UserLogin />} />
        <Route path="sign-up" element={<Register />} />
        <Route path="forget-password" element={<ForgotPassword />} /> 
        <Route path="verify-otp" element={<VerifyPasswordOtp />} /> 
        <Route path="create-password" element={<CreatePassword/>} /> 
         <Route path="organization-login" element={<OrganizationLogin/>}/>


        <Route element={<UserLayout />}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="my-courses" element={<Course />} />
          <Route path="notification" element={< Notification/>} />
          <Route path="my-profile" element={< Profile/>} />
          <Route path="new-requested-service" element={< NewServiceRequest/>} />
          <Route path="my-service" element={< MyService/>} />
          <Route path="my-service2" element={< MyService2/>} />

        </Route>
    </Routes>
  );
};

export default UserRoutes;